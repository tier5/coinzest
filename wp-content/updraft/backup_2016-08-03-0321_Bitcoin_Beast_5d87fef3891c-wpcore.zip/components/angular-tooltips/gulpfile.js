/*global require*/
(function gulpConfig(require) {
  'use strict';

  require('require-dir')('conf/tasks');
}(require));
