<?include("FrontEnd/head.php");?>
<?include("FrontEnd/header.php");?>


<section class="content-section video-section"> 
    <!-- TOP BAR -->
    <div class="container-fluid"> </div>
    <!-- /TOP BAR -->
    <div class="pattern-overlay"> <a id="bgndVideo" class="player" data-property="{videoURL:'https://www.youtube.com/watch?v=j5q780fa1vY',containment:'.video-section', quality:'large', autoPlay:true, mute:true, opacity:1}">bg</a>
          <div id="myCarousel" class="carousel slide" data-ride="carousel"> 
        <!-- Wrapper for slides -->
        <div class="carousel-inner">
         </div>
        <!-- End Carousel Inner -->
        
      </div>
          <!-- End Carousel --> 
        </div>
  </section>

	
	<section class="z-index-1020 inner-info-block">
		<div class="container">
			<!--
			<div id="features-panels" class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="">
					<div class="panel panel-default">
					
						<div class="panel-body">
							<div class="row">
								<div class="col-xs-12 col-sm-3 col-md-3 col-lg-3 hidden-xs text-center">
									<i class="fa fa-globe fa-5x text-info"></i>
								</div>
								<div class="col-xs-12 col-sm-9 col-md-9 col-lg-9">
									<h3 style="color:#fff">
										News
									</h3>
									<p>
										<marquee  behavior="scroll" direction="up" scrolldelay="100" height="320" scrollamount="2" onMouseOver="this.setAttribute('scrollamount', 0, 0);" OnMouseOut="this.setAttribute('scrollamount', 2, 0);">
<br>

							<br/><br/><br/><span class="dark-date"><b>4/24/2016</b></span><br/>
							<span class="dark-name"><b>CO-ORDINATORS REQUIRED FOR EACH COUNTRY</b></span><br/>

							<span class="dark-comment">DEAR MEMBERS ! CO-ORDINATOR REQUIRED FOR EACH COUNTRY. ELIGIBILITY FOR BECOMING CO-ORDINATOR. 
1. DIRECT 50 CONFIRMED MEMBER IN DOWNLINE. 500+ MEMBERS IN TOTAL TEAM. RESPONSIBILITY 
2. HELPING AND SUPPORTING YOUR COUNTRY MEMBERS. 

* SALARY UPTO $200 THANK YOU BITCOIN BEAST TEAM 
* SKYPE: MIKE_LEO70  </span>
							
							<br/><br/><br/><span class="dark-date"><b>4/20/2016</b></span><br/>
							<span class="dark-name"><b>PH LIMIT INCREASED FOR SPECIAL MEMBERS ONLY</b></span><br/>

							<span class="dark-comment">DEAR ALL, WE INCREASED A PH LIMIT FOR THOSE MEMBERS WHO COMPLETED THEIR PH WITH 500$, NOW THEY CAN MAKE PH UPTO 1000$  </span>
							
							<br/><br/><br/><span class="dark-date"><b>4/15/2016</b></span><br/>
							<span class="dark-name"><b>!!! 80% PH LINK RELEASING NOTIFICATION !!!</b></span><br/>

							<span class="dark-comment">DEAR MEMBERS ! 17TH MARCH AND 18TH MARCH, PROVIDE HELP COMMITMENT OF 80%  LINKS ARE DISPATCHED. KINDLY CHECK YOUR ACCOUNTS FOR COMPLETING PAYMENTS. IF SENDER FAILS TO COMPLETE HIS/HER PAYMENT IN GIVEN ALLOTTED TIME. HIS/HER ID WILL BE BLOCKED PERMANENTLY. AFTER THAT ID CAN NOT BE UNBLOCKED. THANK YOU BITCOIN-BEAST TEAM !  </span>
							
							<br/><br/><br/><span class="dark-date"><b>4/11/2016</b></span><br/>
							<span class="dark-name"><b>!!! PH LINK RELEASING NOTIFICATION !!! </b></span><br/>

							<span class="dark-comment">DEAR MEMBERS !

6th APRIL AND 7TH APRIL PROVIDE HELP COMMITMENT LINKS ARE DISPATCHED.
KINDLY CHECK YOUR ACCOUNTS FOR COMPLETING PAYMENTS.
IF SENDER FAILS TO COMPLETE HIS/HER PAYMENT IN GIVEN ALLOTTED TIME. HIS/HER ID WILL BE BLOCKED PERMANENTLY. AFTER THAT ID CAN NOT BE UNBLOCKED.

THANK YOU
BITCOIN-BEAST TEAM !  </span>
							
							<br/><br/><br/><span class="dark-date"><b>4/3/2016</b></span><br/>
							<span class="dark-name"><b>!!! CO-ORDINATORS REQUIRED IN ALL COUNTRIES !!!</b></span><br/>

							<span class="dark-comment">DEAR MEMBERS !

CO-ORDINATOR REQUIRED IN EACH COUNTY.

*ELIGIBILITY FOR BECOMING CO -ORDINATOR.

  1.DIRECT 50 CONFIRMED MEMBER IN DOWNLINE.
  2.500+ MEMBERS IN TOTAL TEAM.

*RESPONSIBILITY

 1.HELPING AND SUPPORTING YOUR COUNTRY MEMBERS.

*SALARY

 1. UPTO $250

THANK YOU
BITCOIN BEAST TEAM 
SKYPE: SUPPORT.BEAST  </span>
							
							<br/><br/><br/><span class="dark-date"><b>4/8/2016</b></span><br/>
							<span class="dark-name"><b>!!! GH LINK RELEASING NOTIFICATION !!!</b></span><br/>

							<span class="dark-comment">DEAR MEMBERS !

7th AND 8th APRIL GET HELP LINKS ARE DISPATCHED.
KINDLY CHECK YOUR ACCOUNTS FOR CONFIRMING PAYMENTS, IF SENDER MAKE PAYMENT.

THANK YOU
BITCOIN-BEAST TEAM !  </span>
							
					
					</marquee>
									</p>
									
							</div>
						</div>
					</div>
				</div>
			</div>
			-->
		</div>
	</section>
	
	
	
	
	


	<section class="support-section">
		
		<div class="container inner-info-block">
			<div class="row">
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 text-center">
					
				<!--	<iframe width="100%" height="315" src="https://www.youtube.com/embed/vzlj4HVr4AE" frameborder="0" allowfullscreen></iframe>-->
                     
                      
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
					<h3><span>WHAT IS BITCOIN</span></h3>
					<p>Bitcoin is the first truly international currency that can be used anywhere in the world. It is our mission to expand Bitcoin's reach to as many people as possible.</p>


<p>Bitcoin is an experimental, decentralized digital currency that enables instant payments to anyone, anywhere in the world.
</p>
<p>
Bitcoin uses peer-to-peer technology to operate with no central authority: managing transactions and issuing money are carried out collectively by the network.</p>
					
				</div>
				
			</div><!-- /.row-->
		</div>
	</section>
	

	<?include("FrontEnd/footer.php");?>
	
	
<?include("FrontEnd/bottom.php");?>
