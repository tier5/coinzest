<script type='text/javascript'>
/*
    (function() {
    var s = document.createElement('script');s.type='text/javascript';s.async=true;s.id='lsInitScript';
    s.src='https://livesupporti.com/Scripts/clientAsync.js?acc=e0f5f7ae-29da-495f-9634-ef1845926c87&skin=Modern';
    var scr=document.getElementsByTagName('script')[0];scr.parentNode.appendChild(s, scr);
    })();
*/
</script>

<!--Start of Tawk.to Script-->
<!--
<script type="text/javascript">
var $_Tawk_API={},$_Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5772ee8e0da1a7b01bec6f3d/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
-->

<script type='text/javascript'>
    (function() {
    var s = document.createElement('script');s.type='text/javascript';s.async=true;s.id='lsInitScript';
    s.src='https://livesupporti.com/Scripts/clientAsync.js?acc=9c2d86a3-5256-4407-b73e-10b2d8341fcb&skin=Modern';
    var scr=document.getElementsByTagName('script')[0];scr.parentNode.appendChild(s, scr);
    })();
</script>
<!--End of Tawk.to Script-->
<div class="wrap">

	<!-- STYLE SWITCHER-->
	<div id="style-switcher">
		<style>
			#style-switcher h2 a {
				
				padding: 10px 10px;
				height:auto;
			}
			#style-switcher{
				background:#2b2b2b;
			}
			#style-switcher a{
				color:#fff;
			}
		</style>
            <h2>Alternative styles(CSS+LESS)<a href="#"><i class="fa fa-cogs fa-2x"></i> Colors</a></h2>
            <div>
                <h3></h3>
                <ul class="" id="color1">
                    
                 
                    <li><a href="#" class="s2" title="2">Theme 2</a></li>
					<li><a href="#" class="s3" title="3">Theme 3</a></li>
					<li><a href="#" class="s4" title="4">Theme 4</a></li>
					<li><a href="#" class="s5" title="5">Theme 5</a></li>
					<li><a href="#" class="s6" title="6">Theme 6</a></li>
					<li><a href="#" class="s7" title="7">Theme 7</a></li>
     
                </ul>
                <!--Menu Color -->
               

            </div>

            <div id="reset"><a href="#" class="btn btn-info">Reset</a></div>

        </div>
		
	<!-- /STYLE SWITCHER-->
	
    
    
<nav class="navbar navbar-inverse" role="navigation">
  <div class="container"> 
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <div class="navbar-brand">
                            
   			
                    
                     </div> </div>
    
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse navbar-ex1-collapse">
      <ul class="nav navbar-nav navbar-right">
            <li class="wow flipInX animated" data-wow-duration="2s" data-wow-delay=".1s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.1s; animation-name: flipInX;" data-wow-animation-name="flipInX"><a href="https://www.facebook.com/groups/1726594794296594/" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li class="wow flipInX animated" data-wow-duration="2s" data-wow-delay=".2s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.2s; animation-name: flipInX;" data-wow-animation-name="flipInX"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        <li class="wow flipInX animated" data-wow-duration="2s" data-wow-delay=".3s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.3s; animation-name: flipInX;" data-wow-animation-name="flipInX"><a href="#"><i class="fa fa-dribbble"></i></a></li>
                        <li class="wow flipInX animated" data-wow-duration="2s" data-wow-delay=".4s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.4s; animation-name: flipInX;" data-wow-animation-name="flipInX"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li class="wow flipInX animated" data-wow-duration="2s" data-wow-delay=".5s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.5s; animation-name: flipInX;" data-wow-animation-name="flipInX"><a href="https://twitter.com"><i class="fa fa-twitter"></i></a></li>
                        <li class="wow flipInX animated" data-wow-duration="2s" data-wow-delay=".6s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.6s; animation-name: flipInX;" data-wow-animation-name="flipInX">
			<!--skype:support.beast?add -->
			<a href="" target="_blank"><i class="fa fa-skype"></i></a></li>
                        <li class="wow flipInX animated" data-wow-duration="2s" data-wow-delay=".7s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.7s; animation-name: flipInX;" data-wow-animation-name="flipInX"><a href="#"><i class="fa fa-github"></i></a></li>
                        <li class="wow flipInX animated" data-wow-duration="2s" data-wow-delay=".8s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.8s; animation-name: flipInX;" data-wow-animation-name="flipInX"><a href="#"><i class="fa fa-youtube"></i></a></li>
                        
                        
        <li><a class="" href="login.php">Login</a></li>
        <!--<li><a class="" href="#">Register</a></li>-->
      </ul>
    </div>
    <!-- /.navbar-collapse --> 
  </div>
</nav>

<section class="brand-section">
  <div class="flex_container">
    <div >
      <div class="col-xs-12 col-sm-5 col-md-5 col-lg-5"> 
        
        <!-- LOGO IMAGE --> 
		<div class="col-sm-6" style="padding-top:5px; padding-left: 3px !important; padding-right:3px; !important">
		<a href="/"> <img style="height:91px;" class="img-responsive" src="FrontEnd/images/logo-old2.png" alt="logo"> </a> 
		</div>
		<div class="col-sm-6" style="padding-top:5px; padding-left:3px !important; padding-right:3px; !important">
			<a href="/"> <img style="height:91px;" class="img-responsive" src="FrontEnd/images/logo.png" alt="logo"> </a> 
		</div>
        <!-- /LOGO IMAGE --> 
      </div>
      <!--<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 hidden-xs">
        <p class="text-right contact-links"> <a href="#" title="">CONTACT US</a> | <i class="fa fa-mobile-phone"></i> <strong>+ 1 800 300 10000</strong> </p>
      </div>-->
      
      <nav class="navbar col-xs-12 col-sm-7 col-md-7 col-lg-7" role="navigation">
                <div>
				  <!-- Brand and toggle get grouped for better mobile display -->
				  <div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex2-collapse" style="background:#1abc9c; color:#5c7ea0; border: 1px solid #5c7ea0;">
                    
                    
					  <span class="sr-only">Toggle navigation</span>
					  <span class="icon-bar"></span>
					  <span class="icon-bar"></span>
					  <span class="icon-bar"></span>
					</button>
					<div class="navbar-brand"> </div>
				  </div>

				  <!-- Collect the nav links, forms, and other content for toggling -->
				  <div class="collapse navbar-collapse navbar-ex2-collapse" style="max-height:auto !important;">
					<ul class="nav navbar-nav pull-right navigation_bar">
                    <li><a href="index.php">HOME </a></li>
					  <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">ABOUT BIT MUTUAL HELP
 <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="business.php">IDEOLOGY
</a></li>
            <li><a href="about.php">What is Bitcoin</a></li>
            <li><a href="bitcoin-history.php">Bitcoin History</a></li>
           
          </ul>
        </li>

			<li><a href="faq.php">FAQ </a></li>
			<li><a href="media.php">Media</a></li>
			<!--<li><a href="testimonials.php">Beast Testimonials</a></li>-->
					 
 <li><a href="#"> Support</a></li>
					  
					</ul>
					
					
				  </div><!-- /.navbar-collapse -->
				  </div>
				</nav>
                
                
    </div>
  </div>
</section>


