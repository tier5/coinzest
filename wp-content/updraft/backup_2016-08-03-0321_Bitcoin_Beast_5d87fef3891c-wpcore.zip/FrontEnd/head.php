<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<link rel="shortcut icon" href="FrontEnd/images/fevicon.png">



<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.5.6/angular.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.5.6/angular-sanitize.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.5.6/angular-messages.js"></script>
<!--<script src="/components/angular-re-captcha/angular-re-captcha.js"></script>-->
<script src="/components/angular-recaptcha/angular-recaptcha.js"></script>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>


<title>BIT MUTUAL HELP</title>

<!-- SWITCHER ONLY FOR DEMO STYLES -->
<link href="FrontEnd/css/switcher.css" rel="stylesheet">
<!-- SWITCHER ONLY FOR DEMO STYLES -->
        

<!-- Bootstrap core CSS -->
<link id="colors" href="FrontEnd/assets/css/themes/flat-cian-theme.css" rel="stylesheet">

<!-- Custom styles for this template -->
<link href="FrontEnd/assets/css/justified-nav-dark.css" rel="stylesheet">
<!-- custom styles-->

<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css" rel="stylesheet">
<!-- Just for debugging purposes. Don't actually copy this line! -->
<!--[if lt IE 9]><script src="../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    
<link rel="stylesheet" href="FrontEnd/css/style.css" />
<link rel="stylesheet" href="FrontEnd/css/animate.css" /> 
    
<script src="FrontEnd/js/wow.min.js"></script>
<script>
	new WOW().init();
</script>

<style>
	.flex_container {
		  display:                 flex;
		  display:                 -webkit-flex; /* Safari 8 */
		  flex-wrap:               wrap;
		  -webkit-flex-wrap:       wrap;         /* Safari 8 */
		  justify-content:         center;
		  -webkit-justify-content: center;       /* Safari 8 */
	}
</style>


</head>
<body>
