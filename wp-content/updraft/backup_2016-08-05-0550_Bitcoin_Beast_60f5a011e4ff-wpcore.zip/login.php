<?include("FrontEnd/head.php");?>
<?include("FrontEnd/header.php");?>

	<script src="//www.google.com/recaptcha/api.js?render=explicit&onload=vcRecaptchaApiLoaded" async defer></script>
	<style>
		.form-control {
		    display: block !important;
		    width: 100% !important;
		    height: 34px !important;
		    padding: 6px 12px !important;
		    font-size: 14px !important;
		    line-height: 1.42857143 !important;
		    color: #555 !important;
		    background-color: #fff !important;
		    background-image: none !important;
		    border: 1px solid #ccc !important;
		    border-radius: 4px !important;
		    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075) !important;
		    box-shadow: inset 0 1px 1px rgba(0,0,0,.075) !important;
		    -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s !important;
		    -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s !important;
		    transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s !important;
		}
	</style>
	<script>
	var app = angular.module('myApp', ['ngSanitize','ngMessages','vcRecaptcha']);

	app.controller('loginController', ['$scope', '$location','$window', '$http', 'vcRecaptchaService', function($scope, $location, $window, $http, vcRecaptchaService) {
		//alert(reCAPTCHA);
		//reCAPTCHA.setPublicKey('6LerrSMTAAAAABVpbmfo_eLvTA6GbIMWEEb3kF-s');
		

		var vm = this;
		//alert($location.url());
		//alert($window.location);
		var current_location = String($window.location);
		//alert(current_location);
		//alert('in here');
		console.info($window.location.hostname);

		var site_origin = $window.location.protocol + '//' + $window.location.host;
		if ($window.location.hostname == "thebitcoinbeast.com") {
			//site_origin = "https:" + '//' + $window.location.host;
		}

		console.info(site_origin);
		vm.t = {};

		//alert(vcRecaptchaService);

		$scope.form_data = {};
		$scope.phone_prefix = "";
		$scope.phone = "";
		$scope.country = "";
		$scope.verify_otp = "";
		$scope.is_duplicate_phone_number = false;
		$scope.complete_phone_number = "";
		$scope.btc_address = "";
		$scope.get_otp_retrieve_login = "";
		$scope.otp_code = "";
		$scope.captcha_widget_id = null;
		$scope.otp_pop_up_url = 'FrontEnd/get_otp_pop_up.html';
		$scope.is_valid_btc_address = false;

		$scope.is_show_sign_in_form = true;
		$scope.show_get_otp_pop_up = false;
		$scope.is_show_first_time_signup_form = false;
		$scope.is_show_verify_otp_form = false;

		/*
		$scope.is_show_sign_in_form = false;
		$scope.show_get_otp_pop_up = false;
		$scope.is_show_first_time_signup_form = true;
		$scope.is_show_verify_otp_form = false;
		*/


		/*
		$scope.is_show_sign_in_form = false;
		$scope.is_show_first_time_signup_form = true;
		*/

		$scope.know_your_otp_click = function() {
			$scope.show_get_otp_pop_up = true;
			$scope.otp_pop_up_url = 'FrontEnd/get_otp_pop_up.html';
			//alert($scope.captcha.response);
		};

		vm.forgot_password_click = function() {
			$scope.otp_pop_up_url = 'FrontEnd/forgot_password.html';
			$scope.show_get_otp_pop_up = true;
			//alert($scope.captcha.response);
		};

		$scope.password_reset_click = function($form) {
			//alert('form is ');
			//alert($form);
			//alert($scope.form_data.get_otp_retrieve_login);
			//alert($form.get_otp_retrieve_login);
			//alert($form.get_otp_retrieve_login.value);

			var obj_data = {};
			obj_data.login = $scope.form_data.reset_password_for_login;
			console.info($scope.form_data.reset_password_for_login);

			//alert($scope.get_otp_retrieve_login);

			$http({
				method: 'POST',
				url: site_origin + '/platform/password_reset/reset_password_for_login/',
				data: {login:$scope.form_data.reset_password_for_login}
			}).success(function (result) {
				//alert(result);
				//$scope.otp_code = result.otp_code;
				//$scope.form_data.get_otp_retrieve_login = '';
				$scope.otp_pop_up_url = 'FrontEnd/forgot_password_result.html';
			});
		};

		$scope.check_btc_address = function() {
			if ($scope.btc_address != "") {
				var obj_data = {};

				// have to check if not already in system
				obj_data.btc_address = $scope.btc_address;
				$http({
					method: 'POST',
					url: site_origin + '/platform/login/check_btc_address/',
					data: {data:obj_data}
				}).success(function (result) {
					if (result.is_valid) {
						//alert('valid address');
						$scope.is_valid_btc_address = true;
					} else {
						$scope.is_valid_btc_address = false;
					}
					//alert(result);
				});
			}
		};

		$scope.get_my_otp_click = function($form) {
			//alert('form is ');
			//alert($form);
			//alert($scope.form_data.get_otp_retrieve_login);
			//alert($form.get_otp_retrieve_login);
			//alert($form.get_otp_retrieve_login.value);

			var obj_data = {};
			obj_data.login = $scope.form_data.get_otp_retrieve_login;

			//alert($scope.get_otp_retrieve_login);

			$http({
				method: 'POST',
				url: site_origin + '/platform/login/reset_otp_code/',
				data: {data:obj_data}
			}).success(function (result) {
				//alert(result);
				$scope.otp_code = result.otp_code;
				//$scope.form_data.get_otp_retrieve_login = '';
				$scope.otp_pop_up_url = 'FrontEnd/get_otp_pop_up_result.html';
			});
		};

		$scope.check_phone_number = function() {
			if ($scope.phone != "") {
				var obj_data = {};

				$scope.complete_phone_number = $scope.transform_phone_number($scope.phone_prefix, $scope.phone);
				obj_data.phone_number = $scope.complete_phone_number;
				obj_data.login = $scope.login;
				$http({
					method: 'POST',
					url: site_origin + '/platform/login/check_phone_number/',
					data: {data:obj_data}
				}).success(function (result) {
					if (result.is_duplicate_phone_number) {
						//alert('valid address');
						$scope.is_duplicate_phone_number = true;
					} else {
						$scope.is_duplicate_phone_number = false;
					}
				});
			}
		};

		$scope.transform_phone_number = function(prefix, phone_number) {
			var temp_prefix = '';
			var temp_phone_number = '';
			temp_prefix = prefix.replace("+", "");
			temp_prefix = temp_prefix.replace("-", "");
			temp_prefix = temp_prefix.replace(" ", "");

			temp_phone_number = phone_number.replace("+", "");
			temp_phone_number = temp_phone_number.replace("-", "");
			temp_phone_number = temp_phone_number.replace(" ", "");
			var temp = '';
			if (temp_prefix != "1") {
				temp = temp_prefix + temp_phone_number;
			} else {
				temp = temp_phone_number;
			}
			return temp;
		}

		
		vm.t.is_submit_verify_otp_error_message = false;
		vm.t.submit_verify_otp_error_message = "";

		// second page
		$scope.first_time_login_submit = function() {
			var obj_data = {};
			
			var obj_data = {};
			//alert($scope.captcha);

			obj_data.captcha = "";
			obj_data.login = $scope.login;
			obj_data.password = $scope.password;
			obj_data.otp = $scope.verify_otp;
			obj_data.country = $scope.country;
			//alert(obj_data.otp);

			
			$http({
				method: 'POST',
				url: site_origin + '/platform/login/authenticate/',
				data: {data:obj_data}
			}).success(function (result) {
				//alert(result);
				if (result.is_verify_opt_timeout) {
					//$window.location = '/login.php';
					$scope.is_show_sign_in_form = false;
					$scope.is_show_verify_otp_form = false;
					$scope.is_show_first_time_signup_form = true;

					vm.t.is_submit_signup_form_error_message = true;
					vm.t.submit_signup_form_error_message = "OTP Timeout. Please retry.";

					vm.t.is_submit_verify_otp_error_message = false;
					
				} else if (result.is_auth_success && result.is_captcha_success) {
					vm.t.is_submit_verify_otp_error_message = false;
					$window.location = site_origin + '/platform/';
				} else {
					if (!result.is_valid_otp_code) {
						vm.t.is_submit_verify_otp_error_message = true;
						vm.t.submit_verify_otp_error_message = "Invalid OTP Code";
					}
				}
			});
		};

		vm.t.submit_signup_form_error_message = "";
		vm.t.is_submit_signup_form_error_message = false;

		$scope.first_time_signin_submit = function() {
			var obj_data = {};
			
			
			//alert('in here');
			//alert($scope.phone_prefix);
			$scope.complete_phone_number = $scope.transform_phone_number($scope.phone_prefix, $scope.phone);
			if ($scope.btc_address != "" && $scope.complete_phone_number != "") {
				var obj_data = {};

				obj_data.btc_address = $scope.btc_address;
				obj_data.phone_number = $scope.complete_phone_number;
				obj_data.login = $scope.login;
				//obj_data.login = "kokjok@s.com";
				$http({
					method: 'POST',
					url: site_origin + '/platform/login/check_first_time_signin_form/',
					data: {data:obj_data}
				}).success(function (result) {
					if (result.is_success) {
						vm.t.is_submit_signup_form_error_message = false;
						$scope.is_show_verify_otp_form = true;
						$scope.is_show_first_time_signup_form = false;
					} else {
					}
				});
			}
		};

		vm.is_verifying_login = false;
		vm.is_invalid_login = false;

		$scope.submit = function() {
			//alert('in here');
			//alert($scope.captcha.response);

			var obj_data = {};
			//alert($scope.captcha);

			obj_data.captcha = $scope.captcha;
			obj_data.login = $scope.login;
			obj_data.password = $scope.password;
			obj_data.otp = $scope.otp;
			obj_data.country = $scope.country;
			vm.is_verifying_login = true;
			vm.is_invalid_login = false;
			//alert(obj_data.otp);

			
			$http({
				method: 'POST',
				url: site_origin + '/platform/login/authenticate/',
				data: {data:obj_data}
			}).success(function (result) {
				//alert(result);
				if (result.is_auth_success && result.is_captcha_success) {
					if (result.is_first_time_login) {
						$scope.is_show_sign_in_form = false;
						$scope.is_show_first_time_signup_form = true;
						vm.is_verifying_login = false;
						vm.is_invalid_login = false;
					} else {
						vm.is_verifying_login = false;
						vm.is_invalid_login = false;
						$window.location = '/platform/';
					}
				} else {
					vm.is_verifying_login = false;
					vm.is_invalid_login = true;
				}
				vcRecaptchaService.reload($scope.captcha_widget_id);
			});

		};

		$scope.goto_login_click = function() {
			$scope.show_get_otp_pop_up = false;
			//alert('in here');
			//alert($scope.captcha.response);
		};

		$scope.set_captcha_widget_id = function (widgetId) {
                    console.info('Created widget ID: %s', widgetId);
                    $scope.captcha_wiget_id = widgetId;
                };

		$scope.cbExpiration = function() {
                    console.info('Captcha expired. Resetting response object');
                    vcRecaptchaService.reload($scope.captcha_widget_id);
		};


		$('.support-section').css('display','');
	}]);

	/*
	app.config(function (reCAPTCHAProvider) {
	       // required, please use your own key :)
	       reCAPTCHAProvider.setPublicKey('6LerrSMTAAAAABVpbmfo_eLvTA6GbIMWEEb3kF-s');
		//reCAPTCHA.setPublicKey('6LerrSMTAAAAABVpbmfo_eLvTA6GbIMWEEb3kF-s');
	       // optional
	       reCAPTCHAProvider.setOptions({
		   theme: 'clean'
	       });
	});
	*/


	</script>


<section ng-app="myApp" class="support-section" style="display:none;background-image:url(FrontEnd/images/secure.jpg); background-size:cover; background-repeat:no-repeat;">

	<div ng-controller="loginController as login_controller">
		<div class="flex_container" ng-show="is_show_verify_otp_form">
			<div>
				<div style="width:500px; margin-bottom:20px;">
					<div class="max-width:100%" style="padding:10px;border: 3px solid white;
					    margin-top: 10px;
					    margin-bottom: 10px;
					    background-color: rgba(26, 188, 156, 0.18);
					    border-radius: 10px;
						overflow:hidden">
					Welcome to Bit Mutual Help. Please Verify Your OTP Code<br>
					</div>
				</div>
				<div style="width:500px;">
					<div class="max-width:100%" style="padding:10px;border: 3px solid white;
	    margin-top: 10px;
	    margin-bottom: 10px;
	    background-color: rgba(26, 188, 156, 0.18);
	    border-radius: 10px;
		overflow:hidden">
						<h3 class="sign" style="padding-bottom:20px;">
							<div class="col-xs-6 col-ms-6 cols-sm-6">
								<img height="70" src="<?=$t->site_url?>/FrontEnd/images/logo-old2.png" border="0">
							</div>
							<div class="col-xs-6 col-ms-6 cols-sm-6">
								<img height="70" ng-src="/FrontEnd/images/logo.png">
							</div>
						</h3>

						<form name="verify_otp_form" class="form-horizontal" role="form" >
							<div class="form-group">
								<div ng-show="login_controller.t.is_submit_verify_otp_error_message" style="color:#ff0000; font-weight:900;">
									{{login_controller.t.submit_verify_otp_error_message}}
								</div>
								<div ng-show="!login_controller.t.is_submit_verify_otp_error_message" style="" class="alert alert-success" role="alert">
								</div>

							</div>
							<div class="form-group">
								<label class="control-label col-sm-2"  style="text-align:left;">OTP</label>
								<div class="col-sm-10">
									<input ng-model="verify_otp" type="text" name="verify_otp" class="form-control login-field" placeholder="OTP Code">
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-sm-2"  style="margin-top:-8px !important; text-align:left;">Member Name</label>
								<div class="col-sm-10" style="line-height:35px;">
									{{login}}
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-sm-2"  style="margin-top:-8px !important; text-align:left;">BTC Address</label>
								<div class="col-sm-10" style="line-height:35px;">
									{{btc_address}}
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-sm-2"  style="margin-top:-8px !important; text-align:left;">Mobile No</label>
								<div class="col-sm-10" style="line-height:35px;">
									{{complete_phone_number}}
								</div>
							</div>
							<button ng-click="first_time_login_submit()" class="btn btn-primary">LOGIN</button>
						</form>
					</div>
				</div>
			</div>
		</div>
		<div class="flex_container" ng-show="is_show_first_time_signup_form">
			<div>
				<div style="width:500px; margin-bottom:20px;">
					<div class="max-width:100%" style="padding:10px;border: 3px solid white;
					    margin-top: 10px;
					    margin-bottom: 10px;
					    background-color: rgba(26, 188, 156, 0.18);
					    border-radius: 10px;
						overflow:hidden">
					Welcome to Bit Mutual Help. Please Complete Your First Time Login Session.<br>
					Please Fill Out The Below Information Correctly To Get OTP Code.
					</div>
				</div>
				<div style="width:500px;">
					<div class="max-width:100%" style="padding:10px;border: 3px solid white;
	    margin-top: 10px;
	    margin-bottom: 10px;
	    background-color: rgba(26, 188, 156, 0.18);
	    border-radius: 10px;
		overflow:hidden">
						<h3 class="sign" style="padding-bottom:20px;">
							<div class="col-xs-6 col-ms-6 cols-sm-6">
								<img height="70" src="<?=$t->site_url?>/FrontEnd/images/logo-old2.png" border="0">
							</div>
							<div class="col-xs-6 col-ms-6 cols-sm-6">
								<img height="70" ng-src="/FrontEnd/images/logo.png">
							</div>
						</h3>

						<form name="first_time_sign_in_form" class="form-horizontal" role="form" >
							<div class="form-group">
								<div ng-show="login_controller.t.is_submit_signup_form_error_message" style="" style="color:#FF0000; font-weight:900;">
									<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
									<span class="sr-only">Error:</span>
									{{login_controller.t.submit_signup_form_error_message}}
								</div>
								<div ng-show="login_controller.t.is_submit_verify_otp_error_message" style="" class="alert alert-success" role="alert">
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-sm-2"  style="margin-top:-8px !important; text-align:left;">Username</label>
								<div class="col-sm-10">
									{{login}}
									<!--
									<input ng-model="login" type="text" name="login" class="form-control login-field" auto-focus placeholder="Login">
									-->
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-sm-2" style="margin-top:-10px !important; text-align:left;" for="btc_password" style="text-align:left;">BTC Address</label>
								<div class="col-sm-10">
									<input ng-model="btc_address"  name="btc_address" type="text" class="form-control" placeholder="BTC Address" ng-change="check_btc_address()">
									<div ng-show="is_valid_btc_address" style="font-weight:900; color: green;">Valid Address</div>
									<div ng-show="!is_valid_btc_address && first_time_sign_in_form.btc_address.$dirty" style="font-weight:900; color: red;">Invalid Address</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-sm-2"  style="margin-top:-8px !important; text-align:left;">Country</label>
								<div class="col-sm-10">
									{{country}}
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-2">
									<input ng-change="check_phone_number()" ng-model="phone_prefix"  name="phone_prefix" type="text" class="form-control" placeholder="+1" style="width:50px !important;">
								</div>
								<div class="col-sm-10">
									<input ng-change="check_phone_number()" ng-model="phone"  name="phone" type="text" class="form-control" placeholder="Mobile No.">
									<div>
										Don't affix '0' or country code.<br>Enter Only Mobile Number.
									</div>
									<div ng-show="is_duplicate_phone_number" style="font-weight:900; color: red;">Duplicate Phone Number</div>
									<div ng-show="!is_duplicate_phone_number && first_time_sign_in_form.phone.$dirty" style="font-weight:900; color: green;">Valid Phone Number</div>
								</div>
							</div>
							<button  ng-click="first_time_signin_submit()" class="btn btn-primary">Update</button>
						</form>
					</div>
				</div>
			</div>
		</div>

		<div class="flex_container" ng-show="is_show_sign_in_form">
			<div style="width:500px;">
				<div class="max-width:100%" style="padding:10px;border: 3px solid white;
    margin-top: 10px;
    margin-bottom: 10px;
    background-color: rgba(26, 188, 156, 0.18);
    border-radius: 10px;
	overflow:hidden">
					<h3 class="sign" style="padding-bottom:20px;">Sign In</h3>

					<div style="position:relative;">
						<div style="color:#000000;position:absolute; top:0px; left:45px; z-index:10000; border:1px solid #a9d2d6; background-color:#FFFFFF; width:390px; height:200px;" ng-show="show_get_otp_pop_up" ng-include="otp_pop_up_url"></div>
					</div>
					<form name="login_form" class="form-horizontal" role="form" >
						<div class="form-group">
							<div class="control-label col-sm-12" style="text-align:left;">
								<div ng-show="login_controller.is_invalid_login" style="color:#FF0000 !important; font-weight:900;" role="alert">
									Unable To Login. Please try again.
								</div>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="login" style="text-align:left;">Email</label>
							<div class="col-sm-10">
								<input ng-model="login" type="text" name="login" class="form-control login-field" auto-focus placeholder="Login">
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="password" style="text-align:left;">Password</label>
							<div class="col-sm-10">
								<input ng-model="password"  name="password" type="password" class="form-control" ng-keyup="$event.keyCode == 13 && submit()" placeholder="Password">
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="otp" style="text-align:left;">OTP</label>
							<div class="col-sm-10">
								<input ng-model="otp" type="password" name="otp" class="form-control" placeholder="OTP">
								<div>
								<a href="" ng-click="know_your_otp_click()">KNOW YOUR OTP</a>
								</div>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="country" style="text-align:left;">Country</label>
							<div class="col-sm-10">
								<select class="form-control" ng-model="country" required name="Country" >
									<option value="Afghanistan">Afghanistan</option>
									<option value="Aland Islands">Aland Islands</option>
									<option value="Albania">Albania</option>
									<option value="Algeria">Algeria</option>
									<option value="American Samoa">American Samoa</option>
									<option value="Andorra">Andorra</option>
									<option value="Angola">Angola</option>
									<option value="Anguilla">Anguilla</option>
									<option value="Antarctica">Antarctica</option>
									<option value="Antigua and Barbuda">Antigua and Barbuda</option>
									<option value="Argentina">Argentina</option>
									<option value="Armenia">Armenia</option>
									<option value="Aruba">Aruba</option>
									<option value="Australia">Australia</option>
									<option value="Austria">Austria</option>
									<option value="Azerbaijan">Azerbaijan</option>
									<option value="Bahamas">Bahamas</option>
									<option value="Bahrain">Bahrain</option>
									<option value="Bangladesh">Bangladesh</option>
									<option value="Barbados">Barbados</option>
									<option value="Belarus">Belarus</option>
									<option value="Belgium">Belgium</option>
									<option value="Belize">Belize</option>
									<option value="Benin">Benin</option>
									<option value="Bermuda">Bermuda</option>
									<option value="Bhutan">Bhutan</option>
									<option value="Bolivia">Bolivia</option>
									<option value="Bonaire">Bonaire</option>
									<option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
									<option value="Botswana">Botswana</option>
									<option value="Bouvet Island">Bouvet Island</option>
									<option value="Brazil">Brazil</option>
									<option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
									<option value="British Virgin Islands">British Virgin Islands</option>
									<option value="Brunei Darussalam">Brunei Darussalam</option>
									<option value="Bulgaria">Bulgaria</option>
									<option value="Burkina Faso">Burkina Faso</option>
									<option value="Burundi">Burundi</option>
									<option value="Cate dIvoire">Cate dIvoire</option>
									<option value="Cambodia">Cambodia</option>
									<option value="Cameroon">Cameroon</option>
									<option value="Canada">Canada</option>
									<option value="Cape Verde">Cape Verde</option>
									<option value="Cayman Islands">Cayman Islands</option>
									<option value="Central African Republic">Central African Republic</option>
									<option value="Chad">Chad</option>
									<option value="Chile">Chile</option>
									<option value="China">China</option>
									<option value="Christmas Island">Christmas Island</option>
									<option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
									<option value="Colombia">Colombia</option>
									<option value="Comoros">Comoros</option>
									<option value="Congo">Congo</option>
									<option value="Cook Islands">Cook Islands</option>
									<option value="Costa Rica">Costa Rica</option>
									<option value="Croatia">Croatia</option>
									<option value="Cuba">Cuba</option>
									<option value="Curaçao">Curaçao</option>
									<option value="Cyprus">Cyprus</option>
									<option value="Czech Republic">Czech Republic</option>
									<option value="Democratic Republic of the Congo">Democratic Republic of the Congo</option>
									<option value="Denmark">Denmark</option>
									<option value="Djibouti">Djibouti</option>
									<option value="Dominica">Dominica</option>
									<option value="Dominican Republic">Dominican Republic</option>
									<option value="Ecuador">Ecuador</option>
									<option value="Egypt">Egypt</option>
									<option value="El Salvador">El Salvador</option>
									<option value="Equatorial Guinea">Equatorial Guinea</option>
									<option value="Eritrea">Eritrea</option>
									<option value="Estonia">Estonia</option>
									<option value="Ethiopia">Ethiopia</option>
									<option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
									<option value="Faroe Islands">Faroe Islands</option>
									<option value="Fiji">Fiji</option>
									<option value="Finland">Finland</option>
									<option value="France">France</option>
									<option value="French Guiana">French Guiana</option>
									<option value="French Polynesia">French Polynesia</option>
									<option value="French Southern Territories">French Southern Territories</option>
									<option value="Gabon">Gabon</option>
									<option value="Gambia">Gambia</option>
									<option value="Georgia">Georgia</option>
									<option value="Germany">Germany</option>
									<option value="Ghana">Ghana</option>
									<option value="Gibraltar">Gibraltar</option>
									<option value="Greece">Greece</option>
									<option value="Greenland">Greenland</option>
									<option value="Grenada">Grenada</option>
									<option value="Guadeloupe">Guadeloupe</option>
									<option value="Guam">Guam</option>
									<option value="Guatemala">Guatemala</option>
									<option value="Guernsey">Guernsey</option>
									<option value="Guinea">Guinea</option>
									<option value="Guinea-Bissau">Guinea-Bissau</option>
									<option value="Guyana">Guyana</option>
									<option value="Haiti">Haiti</option>
									<option value="Heard Island and McDonald Mcdonald Islands">Heard Island and McDonald Mcdonald Islands</option>
									<option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
									<option value="Honduras">Honduras</option>
									<option value="Hong Kong S.A.R.">Hong Kong S.A.R.</option>
									<option value="Hungary">Hungary</option>
									<option value="Iceland">Iceland</option>
									<option value="India">India</option>
									<option value="Indonesia">Indonesia</option>
									<option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
									<option value="Iraq">Iraq</option>
									<option value="Ireland">Ireland</option>
									<option value="Isle of Man">Isle of Man</option>
									<option value="Israel">Israel</option>
									<option value="Italy">Italy</option>
									<option value="Jamaica">Jamaica</option>
									<option value="Japan">Japan</option>
									<option value="Jersey">Jersey</option>
									<option value="Jordan">Jordan</option>
									<option value="Kazakhstan">Kazakhstan</option>
									<option value="Kenya">Kenya</option>
									<option value="Kiribati">Kiribati</option>
									<option value="Korea North">Korea North</option>
									<option value="Korea South">Korea South</option>
									<option value="Kuwait">Kuwait</option>
									<option value="Kyrgyzstan">Kyrgyzstan</option>
									<option value="Lao Peoples Democratic Republic">Lao Peoples Democratic Republic</option>
									<option value="Latvia">Latvia</option>
									<option value="Lebanon">Lebanon</option>
									<option value="Lesotho">Lesotho</option>
									<option value="Liberia">Liberia</option>
									<option value="Libya">Libya</option>
									<option value="Liechtenstein">Liechtenstein</option>
									<option value="Lithuania">Lithuania</option>
									<option value="Luxembourg">Luxembourg</option>
									<option value="Macao">Macao</option>
									<option value="Macedonia, the Former Yugoslav Republic of">Macedonia, the Former Yugoslav Republic of</option>
									<option value="Madagascar">Madagascar</option>
									<option value="Malawi">Malawi</option>
									<option value="Malaysia">Malaysia</option>
									<option value="Maldives">Maldives</option>
									<option value="Mali">Mali</option>
									<option value="Malta">Malta</option>
									<option value="Marshall Islands">Marshall Islands</option>
									<option value="Martinique">Martinique</option>
									<option value="Mauritania">Mauritania</option>
									<option value="Mauritius">Mauritius</option>
									<option value="Mayotte">Mayotte</option>
									<option value="Mexico">Mexico</option>
									<option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
									<option value="Moldova, Republic of">Moldova, Republic of</option>
									<option value="Monaco">Monaco</option>
									<option value="Mongolia">Mongolia</option>
									<option value="Montenegro">Montenegro</option>
									<option value="Montserrat">Montserrat</option>
									<option value="Morocco">Morocco</option>
									<option value="Mozambique">Mozambique</option>
									<option value="Myanmar">Myanmar</option>
									<option value="Namibia">Namibia</option>
									<option value="Nauru">Nauru</option>
									<option value="Nepal">Nepal</option>
									<option value="Netherlands">Netherlands</option>
									<option value="New Caledonia">New Caledonia</option>
									<option value="New Zealand">New Zealand</option>
									<option value="Nicaragua">Nicaragua</option>
									<option value="Niger">Niger</option>
									<option value="Nigeria">Nigeria</option>
									<option value="Niue">Niue</option>
									<option value="Norfolk Island">Norfolk Island</option>
									<option value="Northern Mariana Islands">Northern Mariana Islands</option>
									<option value="Norway">Norway</option>
									<option value="Oman">Oman</option>
									<option value="Pakistan">Pakistan</option>
									<option value="Palau">Palau</option>
									<option value="Palestine, State of">Palestine, State of</option>
									<option value="Panama">Panama</option>
									<option value="Papua New Guinea">Papua New Guinea</option>
									<option value="Paraguay">Paraguay</option>
									<option value="Peru">Peru</option>
									<option value="Philippines">Philippines</option>
									<option value="Pitcairn">Pitcairn</option>
									<option value="Poland">Poland</option>
									<option value="Portugal">Portugal</option>
									<option value="Puerto Rico">Puerto Rico</option>
									<option value="Qatar">Qatar</option>
									<option value="Reunion">Reunion</option>
									<option value="Romania">Romania</option>
									<option value="Russia">Russia</option>
									<option value="Rwanda">Rwanda</option>
									<option value="Saint Barthalemy">Saint Barthalemy</option>
									<option value="Saint Helena">Saint Helena</option>
									<option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
									<option value="Saint Lucia">Saint Lucia</option>
									<option value="Saint Martin (French part)">Saint Martin (French part)</option>
									<option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
									<option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
									<option value="Samoa">Samoa</option>
									<option value="San Marino">San Marino</option>
									<option value="Sao Tome and Principe">Sao Tome and Principe</option>
									<option value="Saudi Arabia">Saudi Arabia</option>
									<option value="Senegal">Senegal</option>
									<option value="Serbia">Serbia</option>
									<option value="Seychelles">Seychelles</option>
									<option value="Sierra Leone">Sierra Leone</option>
									<option value="Singapore">Singapore</option>
									<option value="Sint Maarten (Dutch part)">Sint Maarten (Dutch part)</option>
									<option value="Slovakia">Slovakia</option>
									<option value="Slovenia">Slovenia</option>
									<option value="Solomon Islands">Solomon Islands</option>
									<option value="Somalia">Somalia</option>
									<option value="South Africa">South Africa</option>
									<option value="South Georgia and the South Sandwich Islands">South Georgia and the South Sandwich Islands</option>
									<option value="South Sudan">South Sudan</option>
									<option value="Spain">Spain</option>
									<option value="Sri Lanka">Sri Lanka</option>
									<option value="Sudan">Sudan</option>
									<option value="Suriname">Suriname</option>
									<option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
									<option value="Swaziland">Swaziland</option>
									<option value="Sweden">Sweden</option>
									<option value="Switzerland">Switzerland</option>
									<option value="Syrian Arab Republic">Syrian Arab Republic</option>
									<option value="Taiwan">Taiwan</option>
									<option value="Tajikistan">Tajikistan</option>
									<option value="Thailand">Thailand</option>
									<option value="Timor-Leste">Timor-Leste</option>
									<option value="Togo">Togo</option>
									<option value="Tokelau">Tokelau</option>
									<option value="Tonga">Tonga</option>
									<option value="Trinidad and Tobago">Trinidad and Tobago</option>
									<option value="Tunisia">Tunisia</option>
									<option value="Turkey">Turkey</option>
									<option value="Turkmenistan">Turkmenistan</option>
									<option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
									<option value="Tuvalu">Tuvalu</option>
									<option value="Uganda">Uganda</option>
									<option value="Ukraine">Ukraine</option>
									<option value="United Arab Emirates">United Arab Emirates</option>
									<option value="United Kingdom">United Kingdom</option>
									<option value="United Republic of Tanzania">United Republic of Tanzania</option>
									<option value="United States">United States</option>
									<option value="Uruguay">Uruguay</option>
									<option value="US Virgin Islands">US Virgin Islands</option>
									<option value="Uzbekistan">Uzbekistan</option>
									<option value="Vanuatu">Vanuatu</option>
									<option value="Venezuela">Venezuela</option>
									<option value="Vietnam">Vietnam</option>
									<option value="Wallis and Futuna">Wallis and Futuna</option>
									<option value="Western Sahara">Western Sahara</option>
									<option value="Yemen">Yemen</option>
									<option value="Zambia">Zambia</option>
									<option value="Zimbabwe">Zimbabwe</option>

								</select>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="captcha" style="text-align:left;">Captcha*</label>
							<div class="col-sm-10">
								<div vc-recaptcha on-expire="cbExpiration()" on-create="set_captcha_widget_id(widgetId)" key="'6LerrSMTAAAAABVpbmfo_eLvTA6GbIMWEEb3kF-s'" ng-model="captcha"></div>
							</div>
						</div>
							<div style="float:left;">
								<button ng-disabled="login_form.$invalid" type="button" ng-click="submit()" class="btn btn-primary">Login</button>
							</div>
							<div style="float:left; padding-left:10px;" ng-show="login_controller.is_verifying_login">
								<div style="color:green; font-weght:900; padding-top:7px;">Verifying Login....</div>
							</div>
							<div style="float:right; padding-top:8px;">
								<a style="color:#FF0000;" ng-click="login_controller.forgot_password_click()">forgot password</a>
							</div>
							<div style="clear:both;"></div>
					</form>
				</div>
			</div>
		</div>


	</div>
</section>

<?include("FrontEnd/footer.php");?>
<?include("FrontEnd/bottom.php");?>
