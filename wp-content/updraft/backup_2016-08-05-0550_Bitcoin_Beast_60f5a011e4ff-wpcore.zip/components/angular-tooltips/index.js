/*global require,module*/
(function commonJS(require, module) {
  'use strict';

  require('./dist/angular-tooltips');

  module.exports = '720kb.tooltips';
}(require, module));
