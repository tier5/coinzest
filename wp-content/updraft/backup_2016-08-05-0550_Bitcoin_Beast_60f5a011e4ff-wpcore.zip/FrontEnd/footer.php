<footer class="">
	<div class="container">
		<div class="row">
			<div class="col-md-3 col-xs-12">
				<!--
				<script>(function(d, s, id) {
				var js, fjs = d.getElementsByTagName(s)[0];
				if (d.getElementById(id)) return;
				js = d.createElement(s); js.id = id;
				js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5";
				fjs.parentNode.insertBefore(js, fjs);
				}(document, 'script', 'facebook-jssdk'));</script>

				<div class="fb-page" data-href="https://www.facebook.com/groups/1726594794296594/" data-tabs="timeline" data-width="256" data-height="195" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div>
				-->
				<?php print file_get_contents(dirname(_FILE__)."/FrontEnd/contents/facebook_footer_left_corner.html");?>

			</div>
			<div class="col-md-3 col-xs-12 address">
			<h1 style="font-size:26px;">
			<font color="#ffffff"><strong>IMPORTANT LINKS</strong>
			</font>
			</h1>
			<ul class="page-footer-list">
			<li><i class="fa fa-angle-right"></i><a href="https://blockchain.info/wallet" target="_blank">Create Block Chain wallet</a></li>
			<li><i class="fa fa-angle-right"></i><a href="http://www.bitgazetteer.com/" target="_blank">Who Accepts Bitcoins</a></li>

			<li><i class="fa fa-angle-right"></i><a href="http://www.preev.com" target="_blank">Current live Bitcoin price </a></li>
			<!--<li><i class="fa fa-angle-right"></i><a href="https://www.btcxindia.com/">Exchanger in india</a></li>-->
			<li><i class="fa fa-angle-right"></i><a href="#" target="_blank">Who has bought bitcoins</a></li>
			<li><i class="fa fa-angle-right"></i><a href="http://blogs.microsoft.com/firehose/2014/12/11/now-you-can-exchange-bitcoins-to-buy-apps-games-and-more-for-windows-windows-phone-and-xbox/" target="_blank">Microsoft accepts bitcoins</a><p></p>

			</li></ul>
			</div>
    <div class="col-md-3 col-xs-12">
            <div class="page-footer">
              <h1 style="font-size:26px; text-transform:uppercase;"><font color="#ffffff">
                <strong>Our Community</strong></font>
              </h1>
              <ul class="page-footer-list">
                <li>
                  <i class="fa fa-angle-right"></i>
                  <a href="about.php">About Us</a>
                </li>
                <li>
                  <i class="fa fa-angle-right"></i>
                  <a href="media.php">Media</a>        
                </li>
              <!--<li>
                  <i class="fa fa-angle-right"></i>
                  <a href="features.asp">Features</a>
                </li>-->
                <li>
                  <i class="fa fa-angle-right"></i>
                  <a href="bitcoin-history.php">About Bitcoin</a>
                </li>
                <li>
                  <i class="fa fa-angle-right"></i>
                  <a href="#">Contact</a>
                </li>
              <!--  <li>
                  <i class="fa fa-angle-right"></i>
                  <a href="terms.asp">Terms & conditions</a>
                </li>-->
              </ul>
            </div>
          </div> 
	  
	   <div class="col-md-3 col-xs-12">
            <div class="text-footer" style="">
              <h1 style="font-size:26px; text-transform:uppercase;"><font color="#ffffff">
                <strong>Bitcoin History</strong></font>
              </h1>
              <p style="text-align:justify;">
               Bitcoin has been here since 2009 and it's here to stay!<br> We 
				are a team of entrepreneurs, professionals, experts, network 
				marketers, and programming geeks who have all come to together 
				to launch a very simple Community around a very complex World. 
				<!--Anyone can join team Bitcoin Beast and begin earning a passive 
				income.-->
              </p>
            </div>
          </div>
	
			
		</div>
		<hr>
		<div class="row">
        <div class="container">
        
        <div class="col-md-6">
       <!-- <p> Copyright © - BitcoinBeast  All Rights Reserved.</p>-->
        </div>
        
        <div class="col-md-6">
        				<ul class="list-inline pull-right">
					    <li class="wow flipInX animated" data-wow-duration="2s" data-wow-delay=".1s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.1s; animation-name: flipInX;" data-wow-animation-name="flipInX"><a href="https://www.facebook.com/groups/1726594794296594/" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li class="wow flipInX animated" data-wow-duration="2s" data-wow-delay=".2s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.2s; animation-name: flipInX;" data-wow-animation-name="flipInX"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        <li class="wow flipInX animated" data-wow-duration="2s" data-wow-delay=".3s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.3s; animation-name: flipInX;" data-wow-animation-name="flipInX"><a href="#"><i class="fa fa-dribbble"></i></a></li>
                        <li class="wow flipInX animated" data-wow-duration="2s" data-wow-delay=".4s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.4s; animation-name: flipInX;" data-wow-animation-name="flipInX"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li class="wow flipInX animated" data-wow-duration="2s" data-wow-delay=".5s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.5s; animation-name: flipInX;" data-wow-animation-name="flipInX"><a href="https://twitter.com"><i class="fa fa-twitter"></i></a></li>
                        <li class="wow flipInX animated" data-wow-duration="2s" data-wow-delay=".6s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.6s; animation-name: flipInX;" data-wow-animation-name="flipInX"><a href="" target="_blank"><i class="fa fa-skype"></i></a></li>
                        <li class="wow flipInX animated" data-wow-duration="2s" data-wow-delay=".7s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.7s; animation-name: flipInX;" data-wow-animation-name="flipInX"><a href="#"><i class="fa fa-github"></i></a></li>
                        <li class="wow flipInX animated" data-wow-duration="2s" data-wow-delay=".8s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.8s; animation-name: flipInX;" data-wow-animation-name="flipInX"><a href="#"><i class="fa fa-youtube"></i></a></li>
				</ul>
                
                <img src="FrontEnd/images/sitelock.png" width="100" style="float:left;"/>
                  
                <img src="FrontEnd/images/footer-img_2.png" width="100" style="float:left; margin-left:20px;"/>
                
        </div>
        </div>
		</div>
	</div><!-- CONTAINER -->
</footer><!-- /FOOTER-->
