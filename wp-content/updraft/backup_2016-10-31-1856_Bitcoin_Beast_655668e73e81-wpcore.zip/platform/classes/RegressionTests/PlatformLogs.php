<?

class RegressionTests_PlatformLogs {


	function test_log() {
		print "testing log\n";
		PlatformLogs::log("test", "hello1");
        }

}
?>
