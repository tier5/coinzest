var BTCAddresses = function() {
	return { 
	}

}();


BTCAddresses.ACTIVE_STATUS_ID = 1;
BTCAddresses.ARCHIVED_STATUS_ID = 2;

