var PHRequests = function() {
	return { 
	}

}();


PHRequests.ACTIVE_STATUS_ID = 1;
PHRequests.COMPLETED_STATUS_ID = 3;
PHRequests.CANCELLED_STATUS_ID = 6;

