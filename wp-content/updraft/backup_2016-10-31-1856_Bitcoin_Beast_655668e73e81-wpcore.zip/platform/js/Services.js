var Services_Common = function() {
	return { 
	}

}();


Services_Common.OVERNIGHT_TYPE_ID = 1;
Services_Common.DAYCARE_TYPE_ID = 2;
Services_Common.GROOMING_TYPE_ID = 3;
Services_Common.TRAINING_TYPE_ID = 4;

