var Users = function() {
	return { 
	}

}();


Users.ACTIVE_STATUS_ID = 1;
Users.BLOCKED_STATUS_ID = 3;
Users.SUSPENDED_STATUS_ID = 4;

