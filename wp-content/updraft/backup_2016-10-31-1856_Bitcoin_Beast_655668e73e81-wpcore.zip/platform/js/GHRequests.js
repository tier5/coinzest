var GHRequests = function() {
	return { 
	}

}();


GHRequests.ACTIVE_STATUS_ID = 1;
GHRequests.COMPLETED_STATUS_ID = 3;

GHRequests.CANCELLED_STATUS_ID = 6;

