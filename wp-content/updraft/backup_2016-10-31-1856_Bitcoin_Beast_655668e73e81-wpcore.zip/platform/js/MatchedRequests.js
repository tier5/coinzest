var MatchedRequests = function() {
	return { 
	}

}();


MatchedRequests.ACTIVE_STATUS_ID = 1;
MatchedRequests.CANCELLED_STATUS_ID = 3;
MatchedRequests.COMPLETED_STATUS_ID = 4;

MatchedRequests.CANCELLED_COMPLETED_STATUS_ID = 30;

